# Overview

This is a Japanese Cherry Blossom Platform - a Flask-based web application that provides user authentication and management with a beautiful Japanese aesthetic. The platform supports both regular user accounts and administrative functions, with a focus on secure authentication using phone numbers as the primary identifier. The application features a bilingual interface (Japanese/English) and includes administrative dashboard functionality for user management.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Template Engine**: Jinja2 templates with Bootstrap 5 for responsive design
- **Styling**: Custom CSS with Japanese cherry blossom theme, Google Fonts (Noto Sans JP for Japanese text)
- **JavaScript**: Vanilla JavaScript for form validation, animations, and interactive elements
- **UI Framework**: Bootstrap 5 with Font Awesome icons
- **Design Pattern**: Server-side rendered templates with progressive enhancement

## Backend Architecture
- **Framework**: Flask web framework with SQLAlchemy ORM
- **Authentication**: Session-based authentication with password hashing using Werkzeug
- **Form Handling**: Flask-WTF for form validation and CSRF protection
- **Database ORM**: SQLAlchemy with DeclarativeBase for database operations
- **Security**: ProxyFix middleware for handling reverse proxy headers

## Database Design
- **User Model**: Phone number as unique identifier, password hashing, profile information
- **Admin Model**: Separate administrative accounts with username-based authentication
- **Schema**: SQLite default with PostgreSQL compatibility via environment configuration
- **Features**: Automatic table creation, connection pooling, and migration support

## Authentication System
- **User Authentication**: Phone number and password-based login system
- **Admin Authentication**: Separate admin login with username/password
- **Session Management**: Flask sessions with configurable secret key
- **Password Security**: Werkzeug password hashing with salt

## Application Structure
- **Modular Design**: Separate files for models, routes, forms, and configuration
- **Configuration**: Environment-based configuration for database and security settings
- **Error Handling**: Flash messaging system for user feedback
- **Internationalization**: Bilingual support (Japanese/English) in templates and forms

# External Dependencies

## Frontend Dependencies
- **Bootstrap 5**: UI framework for responsive design and components
- **Font Awesome**: Icon library for visual elements
- **Google Fonts**: Noto Sans JP and Inter fonts for typography

## Backend Dependencies
- **Flask**: Core web framework
- **Flask-SQLAlchemy**: Database ORM integration
- **Flask-WTF**: Form handling and validation
- **WTForms**: Form field definitions and validation
- **Werkzeug**: WSGI utilities and security functions

## Database
- **Default**: SQLite for development
- **Production Ready**: PostgreSQL support via DATABASE_URL environment variable
- **Features**: Connection pooling, automatic reconnection, and schema management

## Deployment
- **WSGI**: Compatible with standard WSGI servers
- **Proxy Support**: ProxyFix middleware for reverse proxy deployment
- **Environment Variables**: Configurable database URL and session secret
- **Port Configuration**: Configurable host and port settings