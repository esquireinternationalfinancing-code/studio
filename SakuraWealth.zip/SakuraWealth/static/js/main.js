// Japanese Cherry Blossom Platform - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the platform
    initializePlatform();
    
    // Initialize form validations
    initializeFormValidation();
    
    // Initialize animations
    initializeAnimations();
    
    // Initialize cherry blossom effects
    initializeCherryBlossoms();
    
    // Initialize Japanese currency formatting
    initializeCurrencyFormatting();
});

// Platform Initialization
function initializePlatform() {
    console.log('🌸 Japanese Cherry Blossom Platform Initialized');
    
    // Add loading states to forms
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitBtn = form.querySelector('input[type="submit"], button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';
                
                // Re-enable after 5 seconds as fallback
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = submitBtn.getAttribute('value') || 'Submit';
                }, 5000);
            }
        });
    });
    
    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

// Form Validation Enhancement
function initializeFormValidation() {
    // Phone number formatting for Japanese numbers
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    phoneInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            
            // Format Japanese phone numbers
            if (value.length >= 3) {
                if (value.startsWith('0')) {
                    // Domestic format: 090-1234-5678
                    value = value.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
                } else if (value.startsWith('81')) {
                    // International format: +81-90-1234-5678
                    value = value.replace(/(\d{2})(\d{2})(\d{4})(\d{4})/, '+$1-$2-$3-$4');
                }
            }
            
            e.target.value = value;
        });
        
        // Add real-time validation
        input.addEventListener('blur', function(e) {
            const value = e.target.value.replace(/\D/g, '');
            const isValid = /^(0[7-9]\d{8}|81[7-9]\d{8})$/.test(value);
            
            if (value && !isValid) {
                e.target.classList.add('is-invalid');
                showValidationError(e.target, 'Please enter a valid phone number');
            } else {
                e.target.classList.remove('is-invalid');
                hideValidationError(e.target);
            }
        });
    });
    
    // Email validation
    const emailInputs = document.querySelectorAll('input[type="email"]');
    emailInputs.forEach(input => {
        input.addEventListener('blur', function(e) {
            const value = e.target.value;
            const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
            
            if (value && !isValid) {
                e.target.classList.add('is-invalid');
                showValidationError(e.target, 'Please enter a valid email address');
            } else {
                e.target.classList.remove('is-invalid');
                hideValidationError(e.target);
            }
        });
    });
    
    // Password strength indicator
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            const password = e.target.value;
            const strength = calculatePasswordStrength(password);
            showPasswordStrength(e.target, strength);
        });
    });
}

// Password Strength Calculator
function calculatePasswordStrength(password) {
    let score = 0;
    let feedback = [];
    
    if (password.length >= 8) {
        score += 1;
    } else {
        feedback.push('Please use 8 or more characters');
    }
    
    if (/[a-z]/.test(password)) score += 1;
    if (/[A-Z]/.test(password)) score += 1;
    if (/\d/.test(password)) score += 1;
    if (/[^a-zA-Z\d]/.test(password)) score += 1;
    
    if (score < 2) feedback.push('Please include uppercase, lowercase, and numbers');
    
    const levels = ['very-weak', 'weak', 'fair', 'good', 'strong'];
    const labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
    
    return {
        score: Math.min(score, 4),
        level: levels[Math.min(score, 4)],
        label: labels[Math.min(score, 4)],
        feedback: feedback
    };
}

// Show Password Strength
function showPasswordStrength(input, strength) {
    let strengthIndicator = input.parentNode.nextElementSibling;
    
    if (!strengthIndicator || !strengthIndicator.classList.contains('password-strength')) {
        strengthIndicator = document.createElement('div');
        strengthIndicator.className = 'password-strength mt-2';
        input.parentNode.insertAdjacentElement('afterend', strengthIndicator);
    }
    
    if (input.value.length === 0) {
        strengthIndicator.innerHTML = '';
        return;
    }
    
    const colors = ['#ef4444', '#f59e0b', '#eab308', '#10b981', '#059669'];
    const color = colors[strength.score];
    
    strengthIndicator.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="password-strength-bar flex-grow-1 me-2">
                <div class="progress" style="height: 4px;">
                    <div class="progress-bar" role="progressbar" 
                         style="width: ${(strength.score + 1) * 20}%; background-color: ${color};">
                    </div>
                </div>
            </div>
            <small style="color: ${color};">${strength.label}</small>
        </div>
        ${strength.feedback.length > 0 ? 
            `<small class="text-muted d-block mt-1">${strength.feedback.join(', ')}</small>` : 
            ''
        }
    `;
}

// Validation Error Handling
function showValidationError(input, message) {
    let errorDiv = input.parentNode.nextElementSibling;
    
    if (!errorDiv || !errorDiv.classList.contains('invalid-feedback')) {
        errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback';
        input.parentNode.insertAdjacentElement('afterend', errorDiv);
    }
    
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

function hideValidationError(input) {
    const errorDiv = input.parentNode.nextElementSibling;
    if (errorDiv && errorDiv.classList.contains('invalid-feedback')) {
        errorDiv.style.display = 'none';
    }
}

// Animation Initialization
function initializeAnimations() {
    // Animate elements on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements with animation classes
    const animatedElements = document.querySelectorAll('.feature-card, .stat-card, .info-card');
    animatedElements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = `all 0.6s ease ${index * 0.1}s`;
        observer.observe(el);
    });
}

// Cherry Blossom Effects
function initializeCherryBlossoms() {
    // Add floating cherry blossoms
    createFloatingCherryBlossoms();
    
    // Add click effects
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('btn')) {
            createClickEffect(e.target, e.clientX, e.clientY);
        }
    });
}

function createFloatingCherryBlossoms() {
    const cherryContainer = document.createElement('div');
    cherryContainer.className = 'cherry-container';
    cherryContainer.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
        overflow: hidden;
    `;
    
    document.body.appendChild(cherryContainer);
    
    // Create floating cherry blossoms periodically
    setInterval(() => {
        if (Math.random() < 0.3) { // 30% chance every interval
            createCherryBlossom(cherryContainer);
        }
    }, 2000);
}

function createCherryBlossom(container) {
    const cherry = document.createElement('div');
    cherry.innerHTML = '🌸';
    cherry.style.cssText = `
        position: absolute;
        top: -50px;
        left: ${Math.random() * 100}%;
        font-size: ${Math.random() * 20 + 10}px;
        opacity: ${Math.random() * 0.5 + 0.3};
        animation: fall ${Math.random() * 10 + 10}s linear forwards;
        transform: rotate(${Math.random() * 360}deg);
    `;
    
    container.appendChild(cherry);
    
    // Remove after animation
    setTimeout(() => {
        if (cherry.parentNode) {
            cherry.parentNode.removeChild(cherry);
        }
    }, 20000);
}

function createClickEffect(element, x, y) {
    const effect = document.createElement('div');
    effect.innerHTML = '🌸';
    effect.style.cssText = `
        position: fixed;
        left: ${x}px;
        top: ${y}px;
        font-size: 20px;
        pointer-events: none;
        z-index: 1000;
        animation: clickEffect 1s ease-out forwards;
        transform: translate(-50%, -50%);
    `;
    
    document.body.appendChild(effect);
    
    setTimeout(() => {
        document.body.removeChild(effect);
    }, 1000);
}

// Japanese Currency Formatting
function initializeCurrencyFormatting() {
    const currencyElements = document.querySelectorAll('.currency, [data-currency]');
    
    currencyElements.forEach(element => {
        const amount = parseFloat(element.textContent.replace(/[^\d.-]/g, ''));
        if (!isNaN(amount)) {
            element.textContent = formatJapaneseCurrency(amount);
        }
    });
}

function formatJapaneseCurrency(amount) {
    return new Intl.NumberFormat('ja-JP', {
        style: 'currency',
        currency: 'JPY',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes fall {
        to {
            transform: translateY(100vh) rotate(360deg);
            opacity: 0;
        }
    }
    
    @keyframes clickEffect {
        0% {
            transform: translate(-50%, -50%) scale(0);
            opacity: 1;
        }
        100% {
            transform: translate(-50%, -50%) scale(2);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Console greeting
console.log(`
🌸 日本の桜プラットフォーム (Japanese Cherry Blossom Platform) 🌸
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
美しい日本の心を込めて作られました
Built with love and Japanese aesthetics
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`);
