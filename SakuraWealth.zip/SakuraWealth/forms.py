from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TelField
from wtforms.validators import DataRequired, Length, Email, Optional, Regexp

class LoginForm(FlaskForm):
    phone_number = TelField('Phone Number', validators=[
        DataRequired(message='Please enter your phone number'),
        Length(min=10, max=15, message='Please enter a valid phone number')
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message='Please enter your password')
    ])
    submit = SubmitField('Login')

class SignupForm(FlaskForm):
    full_name = StringField('Full Name', validators=[
        DataRequired(message='Please enter your full name'),
        Length(min=2, max=100, message='Name must be between 2 and 100 characters')
    ])
    phone_number = TelField('Phone Number', validators=[
        DataRequired(message='Please enter your phone number'),
        Length(min=10, max=15, message='Please enter a valid phone number')
    ])
    email = StringField('Email Address', validators=[
        Optional(),
        Email(message='Please enter a valid email address')
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message='Please enter a password'),
        Length(min=6, message='Password must be at least 6 characters long')
    ])
    submit = SubmitField('Create Account')

class AdminLoginForm(FlaskForm):
    username = StringField('Admin Username', validators=[
        DataRequired(message='Please enter your username')
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message='Please enter your password')
    ])
    submit = SubmitField('Admin Login')
