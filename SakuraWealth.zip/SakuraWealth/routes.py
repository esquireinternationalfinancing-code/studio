from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from app import app, db
from models import User, Admin
from forms import LoginForm, SignupForm, AdminLoginForm

# Helper function to format Japanese currency
def format_currency(amount):
    return f'¥{amount:,}'

app.jinja_env.filters['currency'] = format_currency

@app.route('/')
def index():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        return render_template('profile.html', user=user)
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('index'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(phone_number=form.phone_number.data).first()
        if user and user.check_password(form.password.data):
            session['user_id'] = user.id
            user.last_login = datetime.utcnow()
            db.session.commit()
            flash('Successfully logged in!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid phone number or password', 'error')
    
    return render_template('login.html', form=form)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if 'user_id' in session:
        return redirect(url_for('index'))
    
    form = SignupForm()
    if form.validate_on_submit():
        # Check if user already exists
        existing_user = User.query.filter_by(phone_number=form.phone_number.data).first()
        if existing_user:
            flash('This phone number is already registered', 'error')
            return render_template('signup.html', form=form)
        
        # Check if email already exists (if provided)
        if form.email.data:
            existing_email = User.query.filter_by(email=form.email.data).first()
            if existing_email:
                flash('This email address is already in use', 'error')
                return render_template('signup.html', form=form)
        
        # Create new user
        user = User(
            full_name=form.full_name.data,
            phone_number=form.phone_number.data,
            email=form.email.data if form.email.data else None,
            password_hash=''
        )
        user.set_password(form.password.data)
        
        db.session.add(user)
        db.session.commit()
        
        # Log in the new user
        session['user_id'] = user.id
        flash('Account created successfully!', 'success')
        return redirect(url_for('index'))
    
    return render_template('signup.html', form=form)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    return render_template('profile.html', user=user)

# Admin routes
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if 'admin_id' in session:
        return redirect(url_for('admin_dashboard'))
    
    form = AdminLoginForm()
    if form.validate_on_submit():
        admin = Admin.query.filter_by(username=form.username.data).first()
        if admin and admin.check_password(form.password.data):
            session['admin_id'] = admin.id
            flash('Successfully logged in as administrator', 'success')
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('admin_login.html', form=form)

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    
    users = User.query.order_by(User.created_at.desc()).all()
    user_count = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    
    return render_template('admin_dashboard.html', 
                         users=users, 
                         user_count=user_count,
                         active_users=active_users)

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_id', None)
    flash('Logged out from administrator account', 'info')
    return redirect(url_for('admin_login'))

@app.route('/admin/toggle_user/<int:user_id>')
def toggle_user(user_id):
    if 'admin_id' not in session:
        return redirect(url_for('admin_login'))
    
    user = User.query.get_or_404(user_id)
    user.is_active = not user.is_active
    db.session.commit()
    
    status = "active" if user.is_active else "inactive"
    flash(f'{user.full_name} has been set to {status}', 'success')
    return redirect(url_for('admin_dashboard'))

# Initialize default admin account
def create_admin():
    with app.app_context():
        admin = Admin.query.filter_by(username='admin').first()
        if not admin:
            admin = Admin(username='admin', password_hash='')
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print("Default admin created: username=admin, password=admin123")
